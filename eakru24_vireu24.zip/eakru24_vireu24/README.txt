Responsiv funktionalitet kan findes ved dokumentet der hedder "picture-Ea.html" i style,img linje 21
regex funktionalitet er i dokument"Func-Victor.js" på linjer 14 og 28
regex input er i dokument "index-Ea.html" på linjer 73-84